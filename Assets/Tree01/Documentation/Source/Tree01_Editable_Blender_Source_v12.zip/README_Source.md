# Tree 01 — Broadleaf Shade Trees (source archive v12; release 1.1.0 candidate)

This archive contains the editable Blender source and a portable Blender Python rebuild script. It is a local candidate only; the product is still Free, and this archive does not imply independent approval or publication.

## Contents

- `Tree01_Broadleaf_Shade_Trees_Source_v12.blend` — editable Blender 5.1.2 scene with the three tree forms at LOD0/1/2, packed bark textures, and showroom ground. Hidden boolean diagnostic duplicates are omitted; the producer retained the unfiltered working source separately.
- `Tree01_Rebuild_v12.py` — regenerates FBX and texture outputs under a `Generated` folder beside the script. It requires Blender 5.1.2 and uses only Blender's Python API.
- `mesh_stats_v12.json` — generated source mesh counts, UV layer names, closed-shell audit and signed bark volumes.

## Rebuild

Run Blender 5.1.2 with `--background --python Tree01_Rebuild_v12.py` from any folder containing this script. The script writes a fresh `Generated` folder; it does not modify the shipped `.blend` source.

## Source triangle counts

Counts below are bark plus foliage triangles per LOD, measured from the shipped Blender source.

| Form | LOD0 | LOD1 | LOD2 |
|---|---:|---:|---:|
| Young Upright | 77,444 | 26,578 | 11,900 |
| Mature Asymmetrical | 96,802 | 33,050 | 16,300 |
| Wind-Swept | 78,398 | 27,340 | 13,842 |

All three trees are stylized generic broadleaf forms; no species or historical accuracy is claimed. This archive does not include animation, SpeedTree integration, seasons, or dense-forest benchmarks.
