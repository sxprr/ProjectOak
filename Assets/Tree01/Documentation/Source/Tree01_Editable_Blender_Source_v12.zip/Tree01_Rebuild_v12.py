import bpy
import bmesh
import math
import json
import os
import random
from array import array
from mathutils import Vector


ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "Generated")
MODEL_DIR = os.path.join(OUT, "models")
TEX_DIR = os.path.join(OUT, "textures")
QA_DIR = os.path.join(OUT, "qa", "blender")
SOURCE_DIR = os.path.join(OUT, "blender_source")
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(TEX_DIR, exist_ok=True)
os.makedirs(QA_DIR, exist_ok=True)
os.makedirs(SOURCE_DIR, exist_ok=True)


def reset_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for data in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for block in list(data):
            if block.users == 0:
                data.remove(block)


def make_bark_textures():
    """A small seamless color/normal pair for the non-directional bark UVs."""
    size = 512
    heights = [[0.0] * size for _ in range(size)]
    base_pixels = array("f")
    normal_pixels = array("f")
    for y in range(size):
        v = y / size
        for x in range(size):
            u = x / size
            broad = math.sin(2.0 * math.pi * (u * 13.0 + 0.22 * math.sin(2.0 * math.pi * v * 4.0)))
            fine = math.sin(2.0 * math.pi * (u * 37.0 + 0.13 * math.sin(2.0 * math.pi * v * 11.0)))
            grain = math.sin(2.0 * math.pi * (u * 79.0 + v * 3.0))
            # Keep bark predominantly longitudinal; strong cross-grain made a false
            # horizontal collar at the trunk/root transition in the prior render.
            cross = math.sin(2.0 * math.pi * (v * 16.0 + 0.08 * math.sin(2.0 * math.pi * u * 9.0)))
            knot = math.exp(-(((u - 0.27) / 0.055) ** 2 + ((v - 0.36) / 0.11) ** 2))
            knot2 = math.exp(-(((u - 0.72) / 0.04) ** 2 + ((v - 0.81) / 0.09) ** 2))
            h = 0.50 + 0.12 * broad + 0.055 * fine + 0.028 * grain + 0.006 * cross - 0.20 * knot - 0.16 * knot2
            heights[y][x] = h
            n = 0.5 + 0.09 * broad + 0.045 * fine + 0.022 * grain + 0.005 * cross - 0.18 * knot - 0.14 * knot2
            warm = 0.5 + 0.5 * n
            r = 0.270 + 0.150 * warm
            g = 0.135 + 0.090 * warm
            b = 0.065 + 0.050 * warm
            base_pixels.extend((r, g, b, 1.0))
    scale = 5.5
    for y in range(size):
        ym = (y - 1) % size
        yp = (y + 1) % size
        for x in range(size):
            xm = (x - 1) % size
            xp = (x + 1) % size
            dx = (heights[y][xp] - heights[y][xm]) * scale
            dy = (heights[yp][x] - heights[ym][x]) * scale
            nx, ny, nz = -dx, -dy, 1.0
            length = math.sqrt(nx * nx + ny * ny + nz * nz)
            normal_pixels.extend((0.5 + 0.5 * nx / length, 0.5 + 0.5 * ny / length, 0.5 + 0.5 * nz / length, 1.0))
    base = bpy.data.images.new("Bark_BaseColor_512", width=size, height=size, alpha=False)
    base.pixels.foreach_set(base_pixels)
    base.filepath_raw = os.path.join(TEX_DIR, "Tree_Bark_BaseColor_v12.png")
    base.file_format = "PNG"
    base.save()
    normal = bpy.data.images.new("Bark_Normal_512", width=size, height=size, alpha=False)
    normal.pixels.foreach_set(normal_pixels)
    normal.filepath_raw = os.path.join(TEX_DIR, "Tree_Bark_Normal_v12.png")
    normal.file_format = "PNG"
    normal.save()
    return base, normal


def make_material(name, color, roughness=0.8, image=None, normal_image=None):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (500, 0)
    shader = nodes.new("ShaderNodeBsdfPrincipled")
    shader.location = (180, 0)
    shader.inputs["Base Color"].default_value = (*color, 1.0)
    shader.inputs["Roughness"].default_value = roughness
    mat.node_tree.links.new(shader.outputs["BSDF"], out.inputs["Surface"])
    if image:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = image
        tex.location = (-400, 60)
        mat.node_tree.links.new(tex.outputs["Color"], shader.inputs["Base Color"])
    if normal_image:
        texn = nodes.new("ShaderNodeTexImage")
        texn.image = normal_image
        texn.location = (-400, -180)
        texn.image.colorspace_settings.name = "Non-Color"
        normal = nodes.new("ShaderNodeNormalMap")
        normal.location = (-80, -160)
        normal.inputs["Strength"].default_value = 0.38
        mat.node_tree.links.new(texn.outputs["Color"], normal.inputs["Color"])
        mat.node_tree.links.new(normal.outputs["Normal"], shader.inputs["Normal"])
    return mat


def curve_sample(points, steps_per_segment=6):
    result = []
    for seg in range(len(points) - 1):
        p0, r0 = points[max(0, seg - 1)]
        p1, r1 = points[seg]
        p2, r2 = points[seg + 1]
        p3, r3 = points[min(len(points) - 1, seg + 2)]
        for step in range(steps_per_segment):
            t = step / steps_per_segment
            t2, t3 = t * t, t * t * t
            def cat(a, b, c, d):
                return 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3)
            pos = Vector((cat(p0.x, p1.x, p2.x, p3.x), cat(p0.y, p1.y, p2.y, p3.y), cat(p0.z, p1.z, p2.z, p3.z)))
            radius = cat(r0, r1, r2, r3)
            result.append((pos, max(0.012, radius)))
    result.append((points[-1][0].copy(), max(0.012, points[-1][1])))
    return result


def tube_geometry(branches, radial_segments, steps_per_segment, rng):
    verts, faces = [], []
    for branch_idx, controls in enumerate(branches):
        samples = curve_sample(controls, steps_per_segment)
        base = len(verts)
        previous_u = None
        phase = rng.random() * math.tau
        for i, (center, radius) in enumerate(samples):
            if i == 0:
                tangent = (samples[1][0] - center).normalized()
            elif i == len(samples) - 1:
                tangent = (center - samples[i - 1][0]).normalized()
            else:
                tangent = (samples[i + 1][0] - samples[i - 1][0]).normalized()
            ref = Vector((0.0, 0.0, 1.0))
            u = tangent.cross(ref)
            if u.length < 0.001:
                ref = Vector((0.0, 1.0, 0.0))
                u = tangent.cross(ref)
            u.normalize()
            if previous_u is not None and u.dot(previous_u) < 0.0:
                u.negate()
            v = tangent.cross(u).normalized()
            previous_u = u.copy()
            for j in range(radial_segments):
                a = math.tau * j / radial_segments
                rib = 1.0 + 0.055 * math.sin(a * 3.0 + phase + i * 0.035) + 0.025 * math.sin(a * 5.0 - phase)
                organic = 1.0 + 0.018 * math.sin(i * 0.31 + phase)
                point = center + radius * rib * organic * (u * math.cos(a) + v * math.sin(a))
                verts.append(tuple(point))
        ring_count = len(samples)
        faces.append(tuple(base + j for j in reversed(range(radial_segments))))
        for i in range(ring_count - 1):
            a0 = base + i * radial_segments
            b0 = base + (i + 1) * radial_segments
            for j in range(radial_segments):
                j2 = (j + 1) % radial_segments
                faces.append((a0 + j, a0 + j2, b0 + j2, b0 + j))
        end = base + (ring_count - 1) * radial_segments
        faces.append(tuple(end + j for j in range(radial_segments)))
    return verts, faces


def make_mesh_object(name, verts, faces, material, recalc=True):
    mesh = bpy.data.meshes.new(name + "Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    if recalc:
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode="OBJECT")
    obj.select_set(False)
    return obj


def triangulate_mesh_object(obj, name):
    """Triangulate a closed mesh in place while preserving its existing UV layers."""
    bpy.ops.object.select_all(action="DESELECT")
    obj.hide_viewport = False
    obj.hide_render = False
    obj.hide_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    triangulate = obj.modifiers.new(name, "TRIANGULATE")
    triangulate.quad_method = "BEAUTY"
    triangulate.ngon_method = "BEAUTY"
    bpy.ops.object.modifier_apply(modifier=triangulate.name)
    obj.select_set(False)
    return obj


def audit_bark_topology(obj, bm=None, strict=True):
    own_bm = bm is None
    if own_bm:
        bm = bmesh.new()
        bm.from_mesh(obj.data)
    bm.normal_update()
    boundary = sum(1 for edge in bm.edges if edge.is_boundary)
    wire = sum(1 for edge in bm.edges if len(edge.link_faces) == 0)
    nonmanifold = sum(1 for edge in bm.edges if not edge.is_manifold)
    inconsistent = sum(1 for edge in bm.edges if edge.is_manifold and not edge.is_contiguous)
    over_two = sum(1 for edge in bm.edges if len(edge.link_faces) > 2)
    loose = sum(1 for vert in bm.verts if len(vert.link_edges) == 0)
    pending = set(bm.faces)
    components = 0
    while pending:
        components += 1
        stack = [pending.pop()]
        while stack:
            face = stack.pop()
            for edge in face.edges:
                for neighbour in edge.link_faces:
                    if neighbour in pending:
                        pending.remove(neighbour)
                        stack.append(neighbour)
    signed_volume = bm.calc_volume(signed=True)
    degenerate_faces = sum(1 for face in bm.faces if face.calc_area() <= 1.0e-12)
    report = {
        "vertices": len(bm.verts), "edges": len(bm.edges), "faces": len(bm.faces),
        "boundary_edges": boundary, "wire_edges": wire, "nonmanifold_edges": nonmanifold,
        "inconsistent_manifold_edges": inconsistent, "edges_over_two_faces": over_two,
        "loose_vertices": loose, "face_components": components,
        "signed_volume_m3": round(signed_volume, 9), "zero_area_faces": degenerate_faces,
    }
    report["pass"] = (boundary == 0 and wire == 0 and nonmanifold == 0 and inconsistent == 0
                       and over_two == 0 and loose == 0 and components == 1
                       and signed_volume > 0.0 and degenerate_faces == 0)
    if own_bm:
        bm.free()
    if strict and not report["pass"]:
        raise RuntimeError("Bark topology gate failed for " + obj.name + ": " + repr(report))
    return report



def trunk_root_geometry(spec, radial_segments, vertical_segments):
    """One closed, tangent-framed loft carries the trunk into tapered root buttresses."""
    sampled_path = curve_sample(spec["trunk"], max(10, vertical_segments))
    # Keep the authored stem above ground, but terminate the connected loft at
    # z=0. Its first ring is the widest root footprint; every lobe grows into
    # that level plane rather than curling to a narrow buried bulb tip.
    path = [(center, radius) for center, radius in sampled_path if center.z >= -1.0e-6]
    if not path or abs(path[0][0].z) > 1.0e-5:
        raise RuntimeError("Trunk path must contain a z=0 ground sample for " + spec["name"])
    root_dirs=[Vector((v[0],v[1],0.0)).normalized() for v in spec["roots"]]
    def flare_at(z):
        # A monotone downward flare has its maximum at the flat ground plane;
        # a broad exponential falloff blends the lobes continuously into trunk.
        z=max(0.0,z)
        return spec["root_span"]*0.40*math.exp(-((z/0.60)**1.55))
    rings=path
    verts=[]; faces=[]; prev_u=None; prev_t=None
    for i,(center,trunk_radius) in enumerate(rings):
        if i == 0:
            tangent=(rings[1][0]-rings[0][0]).normalized()
        elif i == len(rings)-1:
            tangent=(rings[-1][0]-rings[-2][0]).normalized()
        else:
            tangent=(rings[i+1][0]-rings[i-1][0]).normalized()
        # Parallel-transport the ring frame. Crossing an arbitrary world-up
        # threshold makes a near-vertical leaning trunk twist abruptly and shade
        # as a false collar; minimal tangent rotation keeps the loft stable.
        if prev_u is None:
            u=Vector((1.0,0.0,0.0))-tangent*tangent.x
            if u.length < 0.001: u=Vector((0.0,1.0,0.0))-tangent*tangent.y
            u.normalize()
        else:
            rot=prev_t.rotation_difference(tangent)
            u=rot @ prev_u
            u-=tangent*u.dot(tangent)
            if u.length < 0.001:
                u=Vector((1.0,0.0,0.0))-tangent*tangent.x
            u.normalize()
        v=tangent.cross(u).normalized(); prev_u=u.copy(); prev_t=tangent.copy()
        local_angles=[]
        for rd in root_dirs:
            projected=rd-tangent*rd.dot(tangent)
            if projected.length<0.001: projected=rd.copy()
            projected.normalize()
            local_angles.append(math.atan2(projected.dot(v),projected.dot(u)))
        ext=flare_at(center.z)
        for j in range(radial_segments):
            theta=math.tau*j/radial_segments
            nearest=max(math.exp(-((math.atan2(math.sin(theta-a),math.cos(theta-a))/0.25)**2)) for a in local_angles)
            lobe=nearest**1.08
            irregularity=1.0+0.008*math.sin(3*theta+spec["seed"]*0.31)+0.005*math.sin(5*theta+spec["seed"]*0.19)
            radius=max(0.025,trunk_radius+ext*lobe*irregularity)
            point=center+radius*(u*math.cos(theta)+v*math.sin(theta))
            verts.append(tuple(point))
    for iz in range(len(rings)-1):
        lower=iz*radial_segments; upper=(iz+1)*radial_segments
        for j in range(radial_segments):
            jn=(j+1)%radial_segments
            faces.append((lower+j,lower+jn,upper+jn,upper+j))
    faces.append(tuple(reversed(range(radial_segments))))
    top=(len(rings)-1)*radial_segments
    faces.append(tuple(top+j for j in range(radial_segments)))
    return verts,faces

def fuse_branch_mesh(name, branches, material, voxel_size, radial_segments, steps, seed, spec=None):
    # Triangulate closed branch and core operands before the exact union. The
    # Boolean result is explicitly triangulated and audited before smoothing so
    # smoothing cannot bend shared collinear intersection chains into conflicting
    # non-planar n-gons at export time.
    operand_collection = bpy.data.collections.new(name + "_BooleanOperands")
    bpy.context.scene.collection.children.link(operand_collection)
    rng = random.Random(seed)
    if spec is None:
        raise RuntimeError("Trunk/root loft specification is required for " + name)
    core_verts, core_faces = trunk_root_geometry(spec, max(40, radial_segments * 4), max(14, steps * 2))
    target = make_mesh_object(name + "_TrunkRootCore", core_verts, core_faces, material)
    triangulate_mesh_object(target, "Triangulate_TrunkRoot_Operand")
    operands = []
    for branch_index, controls in enumerate(branches):
        branch_verts, branch_faces = tube_geometry([controls], radial_segments, steps, rng)
        part = make_mesh_object(name + "_Solid_%03d" % branch_index, branch_verts, branch_faces, material)
        triangulate_mesh_object(part, "Triangulate_Branch_Operand")
        for collection in list(part.users_collection):
            collection.objects.unlink(part)
        operand_collection.objects.link(part)
        operands.append(part)
    if not operands:
        raise RuntimeError("Expected trunk/branches to union with root flare for " + name)
    bpy.context.view_layer.objects.active = target
    bpy.ops.object.select_all(action="DESELECT")
    target.select_set(True)
    boolean = target.modifiers.new("Exact_Fused_Branch_Union", "BOOLEAN")
    boolean.operation = "UNION"
    boolean.operand_type = "COLLECTION"
    boolean.collection = operand_collection
    boolean.solver = "MANIFOLD"
    boolean.use_self = True
    bpy.ops.object.modifier_apply(modifier=boolean.name)
    for operand in operands:
        bpy.data.objects.remove(operand, do_unlink=True)
    bpy.data.collections.remove(operand_collection)
    target.name = name
    target.data.name = name + "Mesh"

    # The buyer generator omits hidden diagnostic duplicates; the pre-smooth
    # source is kept only in the producer working archive.

    # Freeze connected triangles before any geometry smoothing, then audit.
    triangulate_mesh_object(target, "ExactUnion_Triangulation_Before_Smooth")
    bm = bmesh.new()
    bm.from_mesh(target.data)
    faces_before_micro_cleanup = len(bm.faces)
    verts_before_micro_cleanup = len(bm.verts)
    degenerate_before_micro_cleanup = sum(1 for face in bm.faces if face.calc_area() <= 1.0e-12)
    # Boolean intersection arithmetic can leave micron-scale collinear sliver
    # triangles (the measured cases are under 2e-6 m across). Dissolve only
    # those short edges into their adjacent faces, then keep the connected shell
    # and retessellate any affected polygon. This is a geometric weld, not a
    # face-only delete; the standard zero-area audit remains unchanged.
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=2.5e-6)
    remaining_nontriangles = [face for face in bm.faces if len(face.verts) != 3]
    if remaining_nontriangles:
        bmesh.ops.triangulate(
            bm, faces=remaining_nontriangles,
            quad_method="BEAUTY", ngon_method="BEAUTY"
        )
    bm.normal_update()
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    signed_volume = bm.calc_volume(signed=True)
    if signed_volume < 0.0:
        bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(target.data)
    target.data.update()
    pre_smooth_report = audit_bark_topology(target, bm=bm, strict=True)
    bm.free()

    # Preserve the successful overall smoothing direction, then locally relax only
    # the five independently confirmed LOD0 branch-junction crossings from v11.
    # Blending is position-only and spatially smooth; it neither deletes faces nor
    # changes the closed-shell topology or UVs. The diagnostic coordinates are in
    # the exported local tree space and are intentionally versioned with this repair.
    pre_smooth_positions = [vertex.co.copy() for vertex in target.data.vertices]
    smooth = target.modifiers.new("Organic_Junction_Smoothing", "SMOOTH")
    smooth.factor = 0.12
    smooth.iterations = 3
    bpy.ops.object.select_all(action="DESELECT")
    target.select_set(True)
    bpy.context.view_layer.objects.active = target
    bpy.ops.object.modifier_apply(modifier=smooth.name)
    hotspot_sets = {
        "Tree_Young_Upright": [
            (0.72418, -1.14570, 2.93225),
            (-0.76750, 0.61805, 3.60353),
        ],
        "Tree_Mature_Asymmetrical": [
            (0.65640, 0.89220, 3.80347),
        ],
        "Tree_Wind_Swept": [
            (1.92118, 0.06190, 3.09225),
            (1.07142, -1.01442, 4.08950),
        ],
    }
    if name.endswith("_LOD0"):
        tree_name = spec["name"]
        centers = [Vector(point) for point in hotspot_sets[tree_name]]
        affected = 0
        for index, vertex in enumerate(target.data.vertices):
            distance = min((vertex.co - center).length for center in centers)
            # Fully return the immediate ~18 mm crossing neighborhood to its
            # audited pre-smooth position; smoothly blend back to the full organic
            # smoothing over the next ~102 mm of surface to avoid a hard seam.
            t = max(0.0, min(1.0, (distance - 0.018) / 0.102))
            blend = t * t * (3.0 - 2.0 * t)
            if blend < 0.999999:
                vertex.co = pre_smooth_positions[index].lerp(vertex.co, blend)
                affected += 1
        target.data.update()
        target["localized_junction_relaxation"] = json.dumps({
            "source": "independent v11 double-precision crossing evidence",
            "tree": tree_name,
            "hotspot_count": len(centers),
            "full_relax_radius_m": 0.018,
            "smooth_falloff_end_m": 0.120,
            "affected_vertices": affected,
            "operation": "position blend toward pre-smooth coordinates; no face deletion or topology change",
        }, sort_keys=True)
    bm = bmesh.new()
    bm.from_mesh(target.data)
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    if bm.calc_volume(signed=True) < 0.0:
        bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bm.to_mesh(target.data)
    target.data.update()
    report = audit_bark_topology(target, bm=bm, strict=True)
    report["union_method"] = "Triangulated branch/core operands; Blender Boolean MANIFOLD collection union"
    report["post_union_triangulation"] = "Explicit triangulation and closed-shell audit before smoothing"
    report["pre_smooth_topology_audit"] = json.dumps(pre_smooth_report, sort_keys=True)
    report["micro_sliver_cleanup"] = json.dumps({
        "operation": "BMesh dissolve_degenerate at 2.5e-6 m followed by retessellation",
        "reason": "Boolean-generated micron-scale collinear slivers",
        "before_vertices": verts_before_micro_cleanup,
        "before_faces": faces_before_micro_cleanup,
        "zero_area_faces_before": degenerate_before_micro_cleanup,
        "after_vertices": pre_smooth_report["vertices"],
        "after_faces": pre_smooth_report["faces"],
        "zero_area_faces_after": pre_smooth_report["zero_area_faces"],
    }, sort_keys=True)
    report["junction_smoothing"] = "Smooth factor 0.12, 3 iterations; LOD0 crossing hotspots spatially blended to pre-smooth positions over 0.018-0.120 m"
    bm.free()
    target["bark_topology_audit"] = json.dumps(report, sort_keys=True)
    # Preserve a stable prefab ground pivot after the shape-only smoothing pass.
    target.data.update()
    ground_adjust = -min(vertex.co.z for vertex in target.data.vertices)
    for vertex in target.data.vertices:
        vertex.co.z += ground_adjust
    target.data.update()
    target["ground_contact_adjustment_m"] = float(ground_adjust)
    target["surface_rebuild"] = "Exact Boolean; fixed triangulation before Smooth; no face deletion"
    for face in target.data.polygons:
        face.use_smooth = True
    target.select_set(False)
    unwrap_object(target)
    return target

def unwrap_object(obj):
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(island_margin=0.012, angle_limit=1.13446)
    bpy.ops.object.mode_set(mode="OBJECT")
    if obj.data.uv_layers:
        uv0 = obj.data.uv_layers.active
        uv0.name = "UVMap"
        uv2 = obj.data.uv_layers.new(name="UV2_Lightmap")
        for i, datum in enumerate(uv2.data):
            datum.uv = uv0.data[i].uv
        obj.data.uv_layers.active_index = len(obj.data.uv_layers) - 1
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.lightmap_pack(PREF_MARGIN_DIV=0.05, PREF_PACK_IN_ONE=True)
        bpy.ops.object.mode_set(mode="OBJECT")
        obj.data.uv_layers.active_index = 0
    obj.select_set(False)


def mesh_stats(obj):
    tri_count = 0
    for poly in obj.data.polygons:
        tri_count += max(0, poly.loop_total - 2)
    return {"vertices": len(obj.data.vertices), "polygons": len(obj.data.polygons), "triangles": tri_count}


def trunk_point_at_height(trunk_path, z):
    samples = curve_sample(trunk_path, 14)
    return min(samples, key=lambda item: abs(item[0].z - z))[0].copy()


def unit(v):
    v = Vector(v)
    if v.length < 0.0001:
        return Vector((1.0, 0.0, 0.0))
    return v.normalized()


def make_branch(start, direction, length, radius, upward=0.2, curve=0.12, seed=0):
    rng = random.Random(seed)
    d = unit(direction)
    side = unit(Vector((-d.y, d.x, 0.0)))
    p0 = Vector(start)
    p3 = p0 + d * length + Vector((0.0, 0.0, upward * length))
    p1 = p0 + d * (length * 0.24) + Vector((0.0, 0.0, upward * length * 0.26)) + side * (curve * length * 0.3)
    p2 = p0 + d * (length * 0.67) + Vector((0.0, 0.0, upward * length * 0.7)) - side * (curve * length * 0.2)
    return [(p0, radius), (p1, radius * 0.79), (p2, radius * 0.44), (p3, max(0.018, radius * 0.13))]


def branch_at(controls, t):
    samples = curve_sample(controls, 18)
    idx = max(0, min(len(samples) - 2, int(t * (len(samples) - 1))))
    local = t * (len(samples) - 1) - idx
    p0, r0 = samples[idx]
    p1, r1 = samples[idx + 1]
    p = p0.lerp(p1, local)
    return p, unit(p1 - p0), (r0 * (1.0 - local) + r1 * local)


def tree_branch_set(spec, lod, seed):
    branches = []
    primary = []
    clusters = []
    trunk = spec["trunk"]
    branches.append(trunk)
    # Trunk/root core is a single continuous loft; separately authored structural branches are unioned to it.
    for i, branch_def in enumerate(spec["primary"]):
        height, dx, dy, length, upward, base_r = branch_def
        p = trunk_point_at_height(trunk, height)
        # The wind-swept form carries its branches in one dominant direction.
        d = unit((dx, dy, 0.0))
        curve = 0.12 + 0.08 * math.sin((i + 1) * 1.4)
        branch = make_branch(p, d, length, base_r, upward=upward, curve=curve, seed=seed + i * 13)
        primary.append(branch)
        branches.append(branch)
        if lod == 0:
            fractions = (0.34, 0.56, 0.76, 0.96)
        elif lod == 1:
            fractions = (0.34, 0.56, 0.76, 0.96)
        else:
            fractions = (0.55, 0.88)
        for j, fraction in enumerate(fractions):
            origin, tangent, parent_radius = branch_at(branch, fraction)
            side = unit(Vector((-dy, dx, 0.12 * (1 if j % 2 == 0 else -1))))
            amount = spec["secondary_length"] * (0.78 + 0.28 * math.sin((i + 1) * 3.1 + j * 1.7))
            # Fan twigs into positive and negative depth planes to keep the canopy legible in silhouette.
            d2 = unit(d * 0.72 + side * ((-1.0 if j % 2 else 1.0) * (0.28 + 0.08 * j)) + Vector((0, 0, 0.38 + 0.10 * (j % 2))))
            secondary = make_branch(origin, d2, amount, max(0.055, parent_radius * 0.67), upward=0.15, curve=0.16, seed=seed + i * 91 + j * 7)
            if lod < 2 or j == len(fractions) - 1:
                branches.append(secondary)
            if lod < 2 or j == len(fractions) - 1:
                clusters.append((secondary[-1][0].copy(), d2.copy(), i * 17 + j))
            if lod == 1 and j < len(fractions) - 1:
                midpoint, mid_tangent, _ = branch_at(secondary, 0.70)
                clusters.append((midpoint.copy(), mid_tangent.copy(), 1200 + i * 17 + j))
            if lod == 0:
                for k, t in enumerate((0.58, 0.86)):
                    p2, tan2, rad2 = branch_at(secondary, t)
                    lateral = unit(Vector((-d2.y, d2.x, 0.0)))
                    d3 = unit(d2 * 0.52 + lateral * (0.55 if k == 0 else -0.55) + Vector((0, 0, 0.48)))
                    twig = make_branch(p2, d3, spec["twig_length"] * (0.88 + .13 * k), max(0.038, rad2 * 0.63), upward=0.12, curve=0.18, seed=seed + 317 + i * 31 + j * 9 + k)
                    branches.append(twig)
                    clusters.append((twig[-1][0].copy(), d3.copy(), 500 + i * 31 + j * 5 + k))
        clusters.append((branch[-1][0].copy(), d.copy(), 900 + i))
        if lod < 2:
            mid, mid_tangent, _ = branch_at(branch, 0.52)
            clusters.append((mid.copy(), mid_tangent.copy(), 1600 + i))
    return branches, clusters, primary


def add_leaf(verts, faces, material_ids, base, direction, length, width_ratio, roll, mat_id):
    forward = unit(direction)
    ref = Vector((0.0, 0.0, 1.0))
    side = forward.cross(ref)
    if side.length < 0.05:
        side = forward.cross(Vector((0.0, 1.0, 0.0)))
    side.normalize()
    normal = forward.cross(side).normalized()
    c, s = math.cos(roll), math.sin(roll)
    side, normal = side * c + normal * s, normal * c - side * s
    # A pointed, softly lobed blade with raised midrib and paired visible faces.
    ts = (0.06, 0.25, 0.50, 0.75, 0.94)
    half_width = length * width_ratio
    outline = []
    for t in ts:
        profile = max(0.015, math.sin(math.pi * t) ** 0.72)
        scallop = 1.0 + 0.11 * math.sin(6.0 * math.pi * t + roll) + 0.05 * math.sin(10.0 * math.pi * t - roll)
        w = half_width * profile * scallop
        center = Vector(base) + forward * (length * t) + normal * (0.035 * math.sin(math.pi * t))
        edge_cup = -0.018 * profile
        left = center + side * w + normal * edge_cup
        outline.append(tuple(left))
    for t in reversed(ts):
        profile = max(0.015, math.sin(math.pi * t) ** 0.72)
        scallop = 1.0 + 0.11 * math.sin(6.0 * math.pi * t + roll) + 0.05 * math.sin(10.0 * math.pi * t - roll)
        w = half_width * profile * scallop
        center = Vector(base) + forward * (length * t) + normal * (0.035 * math.sin(math.pi * t))
        edge_cup = -0.018 * profile
        right = center - side * w + normal * edge_cup
        outline.append(tuple(right))
    top_center = Vector(base) + forward * (length * 0.49) + normal * (0.060 * length)
    start = len(verts)
    verts.extend(outline)
    verts.append(tuple(top_center))
    center_index = start + len(outline)
    front_face_indices = []
    for i in range(len(outline)):
        tri = (center_index, start + i, start + ((i + 1) % len(outline)))
        va, vb, vc = (Vector(verts[j]) for j in tri)
        if (vb - va).cross(vc - va).dot(normal) < 0.0:
            tri = (tri[0], tri[2], tri[1])
        front_face_indices.append(tri)
    faces.extend(front_face_indices)
    # Duplicate with opposite winding and a minute offset so Unity's Standard shader
    # renders a correctly lit face from either side without relying on alpha cards.
    back_start = len(verts)
    verts.extend(tuple(Vector(point) - normal * 0.0015) for point in outline)
    verts.append(tuple(top_center - normal * 0.0015))
    back_center = back_start + len(outline)
    for tri in front_face_indices:
        # Restore local indices, then reverse the winding for the back face.
        local = [index - start for index in tri]
        faces.append((back_start + local[0], back_start + local[2], back_start + local[1]))
    material_ids.extend([mat_id] * (len(outline) * 2))


def make_foliage(name, clusters, lod, material_set, seed, spec):
    rng = random.Random(seed + 1700 + lod)
    if lod == 0:
        keep_clusters, leaf_count = clusters, 8
        length_range = spec["leaf_length"]
    elif lod == 1:
        keep_clusters = clusters
        leaf_count = 5
        length_range = (spec["leaf_length"][0] * 1.12, spec["leaf_length"][1] * 1.12)
    else:
        keep_clusters = clusters
        leaf_count = 4
        length_range = (spec["leaf_length"][0] * 1.28, spec["leaf_length"][1] * 1.28)
    verts, faces, face_materials = [], [], []
    for center, axis, cluster_id in keep_clusters:
        phase = rng.random() * math.tau
        for i in range(leaf_count):
            angle = phase + math.tau * i / leaf_count + rng.uniform(-0.22, 0.22)
            radial = Vector((math.cos(angle), math.sin(angle), rng.uniform(-0.25, 0.50)))
            direction = unit(Vector(axis) * 0.22 + radial * 0.74 + Vector((0.0, 0.0, rng.uniform(0.12, 0.55))))
            length = rng.uniform(*length_range)
            base = Vector(center) + direction * rng.uniform(0.015, 0.07)
            # Assign shade/mid/sun leaf tones by face orientation and deterministic variation.
            tone = 2 if direction.z > 0.50 and rng.random() < 0.62 else (0 if direction.z < 0.03 and rng.random() < 0.7 else 1)
            add_leaf(verts, faces, face_materials, base, direction, length, rng.uniform(0.31, 0.38), rng.uniform(-math.pi, math.pi), tone)
    obj = make_mesh_object(name, verts, faces, None, recalc=False)
    for mat in material_set:
        obj.data.materials.append(mat)
    # Material id indices are appended in face order by add_leaf.
    for index, face in enumerate(obj.data.polygons):
        face.material_index = face_materials[index] if index < len(face_materials) else 1
        face.use_smooth = False
    obj.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(island_margin=0.008, angle_limit=1.15)
    bpy.ops.object.mode_set(mode="OBJECT")
    obj.select_set(False)
    if obj.data.uv_layers:
        uv0 = obj.data.uv_layers.active
        uv0.name = "UVMap"
        uv2 = obj.data.uv_layers.new(name="UV2_Lightmap")
        for i, datum in enumerate(uv2.data):
            datum.uv = uv0.data[i].uv
        obj.data.uv_layers.active_index = len(obj.data.uv_layers) - 1
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.lightmap_pack(PREF_MARGIN_DIV=0.05, PREF_PACK_IN_ONE=True)
        bpy.ops.object.mode_set(mode="OBJECT")
        obj.select_set(False)
        obj.data.uv_layers.active_index = 0
    return obj


def root_paths(spec):
    return spec["roots"]


def build_one_tree(spec, bark, leaves, lod):
    name = spec["name"]
    branches, clusters, primaries = tree_branch_set(spec, lod, spec["seed"])
    # The lofted trunk-root core replaces the original separate trunk tube.
    branches = branches[1:]
    # LOD variants progressively lower branch order and surface resolution.
    if lod == 0:
        voxel, radial, steps = 0.045, 10, 7
    elif lod == 1:
        voxel, radial, steps = 0.072, 8, 5
    else:
        voxel, radial, steps = 0.118, 6, 4
    bark_obj = fuse_branch_mesh(name + "_Bark_LOD" + str(lod), branches, bark, voxel, radial, steps, spec["seed"] + lod * 117, spec)
    foliage_obj = make_foliage(name + "_Foliage_LOD" + str(lod), clusters, lod, leaves, spec["seed"], spec)
    ground_adjust = float(bark_obj.get("ground_contact_adjustment_m", 0.0))
    if ground_adjust:
        # Keep the separate foliage mesh aligned with the baked bark ground pivot.
        for vertex in foliage_obj.data.vertices:
            vertex.co.z += ground_adjust
        foliage_obj.data.update()
    # A few tapered, integrated-looking dormant stubs improve trunk and branch close-ups.
    # They are fused into the existing bark mesh only at LOD0; lower LODs rely on the main branch silhouette.
    for obj in (bark_obj, foliage_obj):
        obj.location = (0.0, 0.0, 0.0)
        obj.rotation_euler = (0.0, 0.0, 0.0)
        obj.scale = (1.0, 1.0, 1.0)
        obj["LOD"] = lod
    bark_obj["UV0"] = "UVMap"
    bark_obj["UV2"] = "UV2_Lightmap"
    foliage_obj["UV0"] = "UVMap"
    foliage_obj["UV2"] = "UV2_Lightmap"
    bpy.ops.object.select_all(action="DESELECT")
    bark_obj.select_set(True)
    foliage_obj.select_set(True)
    bpy.context.view_layer.objects.active = bark_obj
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return bark_obj, foliage_obj, clusters


def save_uv_layout(obj, path):
    hidden_viewport = obj.hide_viewport
    hidden_render = obj.hide_render
    obj.hide_viewport = False
    obj.hide_render = False
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    obj.data.uv_layers.active_index = 0
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.uv.export_layout(filepath=path, size=(1024, 1024), opacity=0.0, mode="PNG")
    obj.select_set(False)
    obj.hide_viewport = hidden_viewport
    obj.hide_render = hidden_render


def export_fbx(objects, path):
    # Triangulate temporary export copies before FBX export. Blender polygons
    # remain editable in the saved source; Unity never triangulates a potentially
    # non-planar Boolean ngon and silently discards its surface.
    export_copies = []
    bpy.ops.object.select_all(action="DESELECT")
    for source in objects:
        copy_obj = source.copy()
        copy_obj.data = source.data.copy()
        copy_obj.name = source.name + "_FBX_Triangulated"
        bpy.context.collection.objects.link(copy_obj)
        bpy.context.view_layer.objects.active = copy_obj
        copy_obj.select_set(True)
        triangulate = copy_obj.modifiers.new("FBX_Explicit_Triangulation", "TRIANGULATE")
        triangulate.quad_method = "BEAUTY"
        triangulate.ngon_method = "BEAUTY"
        bpy.ops.object.modifier_apply(modifier=triangulate.name)
        export_copies.append(copy_obj)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in export_copies:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = export_copies[0]
    bpy.ops.export_scene.fbx(
        filepath=path,
        use_selection=True,
        object_types={"MESH"},
        apply_unit_scale=True,
        global_scale=1.0,
        apply_scale_options="FBX_SCALE_UNITS",
        axis_forward="-Z",
        axis_up="Y",
        use_mesh_modifiers=True,
        mesh_smooth_type="FACE",
        colors_type="SRGB",
        path_mode="COPY",
        embed_textures=False,
        add_leaf_bones=False,
        bake_space_transform=False,
        use_custom_props=True,
    )
    bpy.ops.object.select_all(action="DESELECT")
    for obj in export_copies:
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def uv_overlap_estimate(mesh, uv_name):
    # Grid-based overlap test at triangle centroids plus vertex triangles, excluding shared edges.
    # This is a conservative lightweight screen; exact UV island layout is retained for reviewer inspection.
    layer = mesh.uv_layers.get(uv_name)
    if not layer:
        return {"status": "missing", "sampled_overlaps": None}
    bins = {}
    overlap_count = 0
    for poly in mesh.polygons:
        loops = list(poly.loop_indices)
        uvs = [layer.data[i].uv.copy() for i in loops]
        points = [mesh.vertices[mesh.loops[i].vertex_index].co for i in loops]
        for tri_idx in range(1, len(uvs) - 1):
            tri = (uvs[0], uvs[tri_idx], uvs[tri_idx + 1])
            center = (tri[0] + tri[1] + tri[2]) / 3.0
            cell = (int(center.x * 96), int(center.y * 96))
            if cell in bins:
                overlap_count += 1
            bins[cell] = tri
    return {"status": "sampled", "sampled_overlaps": overlap_count, "sample_count": len(bins)}


def save_uv_reports(assets):
    for tree_name, objs in assets.items():
        for lod, (bark_obj, foliage_obj) in objs.items():
            save_uv_layout(bark_obj, os.path.join(QA_DIR, tree_name + "_LOD" + str(lod) + "_Bark_UV0.png"))
            save_uv_layout(foliage_obj, os.path.join(QA_DIR, tree_name + "_LOD" + str(lod) + "_Leaves_UV0.png"))


def setup_render_scene(specs, assets, bark_mat, leaf_mats):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.eevee.taa_render_samples = 64
    scene.render.resolution_x = 1800
    scene.render.resolution_y = 1050
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.world.use_nodes = True
    world_bg = scene.world.node_tree.nodes.get("Background")
    world_bg.inputs["Color"].default_value = (0.36, 0.43, 0.50, 1.0)
    world_bg.inputs["Strength"].default_value = 0.55
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    ground_mat = make_material("QA_Ground", (0.20, 0.24, 0.19), 0.94)
    bpy.ops.mesh.primitive_plane_add(size=40, location=(0, 0, -0.02))
    ground = bpy.context.object
    ground.name = "QA_Ground_Plane"
    ground.data.materials.append(ground_mat)
    lineup = []
    centers = (-8.3, 0.0, 8.3)
    for x, spec in zip(centers, specs):
        for lod, bundle in assets[spec["name"]].items():
            for part in bundle[:2]:
                part.location.x += x
        # Render only LOD0 for the hero sheet.
        bark_obj, foliage_obj, _ = assets[spec["name"]][0]
        lineup.extend((bark_obj, foliage_obj))
        for lod, bundle in assets[spec["name"]].items():
            if lod > 0:
                for part in bundle[:2]:
                    part.hide_render = True
                    part.hide_viewport = True
    # Camera points at the full lineup from a slight front-quarter angle.
    cam_data = bpy.data.cameras.new("QA_Hero_Camera")
    cam = bpy.data.objects.new("QA_Hero_Camera", cam_data)
    bpy.context.collection.objects.link(cam)
    cam.location = (0.0, -23.0, 8.0)
    target = Vector((0.0, 0.0, 2.65))
    cam.rotation_euler = (target - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = 29.5
    scene.camera = cam
    def area(name, location, energy, size, color):
        light_data = bpy.data.lights.new(name, "AREA")
        light_data.energy = energy
        light_data.shape = "DISK"
        light_data.size = size
        light_data.color = color
        light_obj = bpy.data.objects.new(name, light_data)
        bpy.context.collection.objects.link(light_obj)
        light_obj.location = location
        light_obj.rotation_euler = (Vector((0, 0, 2.2)) - light_obj.location).to_track_quat("-Z", "Y").to_euler()
    area("QA_Key_Area", (-8, -11, 13), 2600, 7.0, (1.0, 0.88, 0.72))
    area("QA_Fill_Area", (9, -3, 8), 1900, 8.0, (0.73, 0.84, 1.0))
    area("QA_Rim_Area", (0, 8, 11), 2100, 6.0, (0.82, 0.9, 1.0))
    scene.render.filepath = os.path.join(QA_DIR, "Tree_ThreeForms_Blender_Hero_v12.png")
    bpy.ops.render.render(write_still=True)
    return ground


def define_specs():
    return [
        {
            "name": "Tree_Young_Upright",
            "seed": 41,
            "height": 4.35,
            "base_radius": 0.25,
            "root_span": 0.78,
            "secondary_length": 0.73,
            "twig_length": 0.43,
            "leaf_length": (0.30, 0.42),
            "roots": [(1, 0.1), (0.35, 1), (-0.8, 0.6), (-1, -0.1), (-0.45, -0.9), (0.7, -0.7)],
            "trunk": [
                (Vector((0.00, 0.00, -0.12)), 0.22),
                (Vector((0.00, 0.00, 0.00)), 0.26),
                (Vector((-0.02, 0.01, 0.36)), 0.27),
                (Vector((-0.04, 0.02, 0.78)), 0.215),
                (Vector((0.05, -0.03, 1.55)), 0.155),
                (Vector((0.13, 0.02, 2.44)), 0.105),
                (Vector((0.08, 0.06, 3.26)), 0.072),
                (Vector((0.17, 0.10, 4.35)), 0.022),
            ],
            "primary": [
                (1.45, 1.0, 0.1, 1.10, 0.28, 0.13),
                (1.72, -0.4, 1.0, 1.18, 0.28, 0.13),
                (1.95, -0.9, -0.55, 1.18, 0.28, 0.125),
                (2.35, 0.35, -1.0, 1.18, 0.24, 0.12),
                (2.55, 0.95, 0.5, 1.10, 0.26, 0.115),
                (2.98, -0.8, 0.25, 0.88, 0.20, 0.095),
                (3.22, 0.45, 0.8, 0.88, 0.18, 0.09),
                (3.44, 0.75, -0.45, 0.74, 0.16, 0.085),
            ],
        },
        {
            "name": "Tree_Mature_Asymmetrical",
            "seed": 87,
            "height": 5.85,
            "base_radius": 0.37,
            "root_span": 1.08,
            "secondary_length": 1.04,
            "twig_length": 0.56,
            "leaf_length": (0.34, 0.48),
            "roots": [(1, 0.05), (0.55, 0.85), (-0.5, 0.9), (-1, 0.2), (-0.85, -0.55), (-0.1, -1), (0.75, -0.6), (0.05, 1)],
            "trunk": [
                (Vector((0.00, 0.00, -0.12)), 0.31),
                (Vector((0.00, 0.00, 0.00)), 0.39),
                (Vector((0.02, -0.02, 0.34)), 0.40),
                (Vector((0.04, -0.03, 0.72)), 0.37),
                (Vector((0.05, -0.03, 1.08)), 0.32),
                (Vector((0.00, 0.05, 1.78)), 0.265),
                (Vector((-0.12, 0.03, 2.62)), 0.205),
                (Vector((0.04, -0.04, 3.45)), 0.15),
                (Vector((0.19, 0.03, 4.27)), 0.105),
                (Vector((0.10, 0.05, 4.95)), 0.072),
                (Vector((0.22, 0.10, 5.85)), 0.02),
            ],
            "primary": [
                (1.92, 1.0, 0.15, 1.92, 0.27, 0.22),
                (2.15, 0.25, 1.0, 2.18, 0.28, 0.22),
                (2.43, -0.85, 0.42, 1.62, 0.30, 0.205),
                (2.72, -0.3, -1.0, 2.32, 0.22, 0.20),
                (3.02, 0.95, -0.45, 2.04, 0.24, 0.19),
                (3.42, 0.60, 0.85, 1.88, 0.26, 0.18),
                (3.73, -0.95, -0.2, 1.70, 0.22, 0.16),
                (4.02, -0.30, 0.88, 1.50, 0.25, 0.15),
                (4.28, 0.88, 0.20, 1.66, 0.20, 0.14),
                (4.47, 0.30, -0.9, 1.32, 0.22, 0.13),
            ],
        },
        {
            "name": "Tree_Wind_Swept",
            "seed": 132,
            "height": 4.65,
            "base_radius": 0.34,
            "root_span": 1.10,
            "secondary_length": 1.00,
            "twig_length": 0.55,
            "leaf_length": (0.35, 0.49),
            "roots": [(-1, 0.0), (-0.55, 0.85), (-0.25, -1), (0.5, 0.85), (0.9, -0.5), (0.1, 1)],
            "trunk": [
                (Vector((0.00, 0.00, -0.12)), 0.29),
                (Vector((0.00, 0.00, 0.00)), 0.36),
                (Vector((-0.02, -0.01, 0.34)), 0.37),
                (Vector((-0.04, -0.02, 0.72)), 0.34),
                (Vector((-0.11, -0.02, 1.20)), 0.285),
                (Vector((-0.31, 0.03, 1.70)), 0.225),
                (Vector((-0.58, 0.08, 2.40)), 0.175),
                (Vector((-0.50, 0.12, 3.10)), 0.12),
                (Vector((-0.20, 0.14, 3.75)), 0.085),
                (Vector((0.12, 0.18, 4.65)), 0.02),
            ],
            "primary": [
                (1.80, 1.0, 0.10, 1.85, 0.13, 0.20),
                (2.10, 1.0, 0.65, 2.20, 0.12, 0.20),
                (2.40, 1.0, -0.72, 2.04, 0.18, 0.19),
                (2.67, 0.95, 0.0, 2.58, 0.16, 0.19),
                (2.93, 0.75, 0.85, 2.30, 0.18, 0.17),
                (3.18, 1.0, -0.45, 2.18, 0.18, 0.16),
                (3.50, 0.93, 0.45, 1.83, 0.22, 0.14),
                (3.74, 0.86, -0.75, 1.62, 0.24, 0.13),
            ],
        },
    ]


def main():
    reset_scene()
    bark_image, normal_image = make_bark_textures()
    bark = make_material("Tree_Bark_Standard", (0.33, 0.19, 0.10), 0.92, bark_image, normal_image)
    leaf_mats = [
        make_material("Leaf_Shade_Green", (0.09, 0.23, 0.07), 0.9),
        make_material("Leaf_Mid_Green", (0.17, 0.36, 0.09), 0.86),
        make_material("Leaf_Sun_Green", (0.32, 0.51, 0.13), 0.82),
    ]
    specs = define_specs()
    assets = {}
    stats = {}
    all_objs = []
    for spec in specs:
        assets[spec["name"]] = {}
        stats[spec["name"]] = {}
        for lod in (0, 1, 2):
            bark_obj, foliage_obj, clusters = build_one_tree(spec, bark, leaf_mats, lod)
            assets[spec["name"]][lod] = (bark_obj, foliage_obj, clusters)
            all_objs.extend((bark_obj, foliage_obj))
            bark_stats = mesh_stats(bark_obj)
            leaf_stats = mesh_stats(foliage_obj)
            stats[spec["name"]][lod] = {
                "height_m": round(spec["height"], 3),
                "cluster_count": len(clusters),
                "bark": bark_stats,
                "bark_topology": json.loads(bark_obj["bark_topology_audit"]),
                "foliage": leaf_stats,
                "combined_triangles": bark_stats["triangles"] + leaf_stats["triangles"],
                "uv_layers_bark": [layer.name for layer in bark_obj.data.uv_layers],
                "uv_layers_foliage": [layer.name for layer in foliage_obj.data.uv_layers],
            }
            print("BUILT", spec["name"], "LOD", lod, stats[spec["name"]][lod])
            path = os.path.join(MODEL_DIR, spec["name"] + "_LOD" + str(lod) + ".fbx")
            export_fbx([bark_obj, foliage_obj], path)
    # Store all editable source meshes and common materials in one native Blender source file.
    bpy.ops.object.select_all(action="DESELECT")
    source_path = os.path.join(SOURCE_DIR, "Tree01_Broadleaf_Shade_Trees_Source_v12.blend")
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=source_path)
    # Rebuild an isolated render scene with the LOD0 versions and neutral ground.
    setup_render_scene(specs, assets, bark, leaf_mats)
    bpy.context.scene.render.filepath = os.path.join(QA_DIR, "Tree_ThreeForms_Blender_Hero_v12.png")
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=source_path)
    uv_assets = {name: {lod: (bundle[0], bundle[1]) for lod, bundle in lods.items()} for name, lods in assets.items()}
    save_uv_reports(uv_assets)
    # Put verification data alongside the generated source and exports.
    with open(os.path.join(OUT, "qa", "blender", "mesh_stats_v12.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)
    print("WROTE", source_path)
    print("STATS", json.dumps(stats, sort_keys=True))


if __name__ == "__main__":
    main()









